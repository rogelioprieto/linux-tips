In windows open the ```PowerShell``` as Administrator:

```Confirm-SecureBootUEFI```

