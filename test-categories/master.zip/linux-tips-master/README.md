# Linux & Ubuntu tips

Here you will find tips for everyday use GNU/Linux and Ubuntu. 
How to install, setup and custom software tools for all purpose that use  command line or a Graphic User Interface (GUI).

¡Welcome and save time!
