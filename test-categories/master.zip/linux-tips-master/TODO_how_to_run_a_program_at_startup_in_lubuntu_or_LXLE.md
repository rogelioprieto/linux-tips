Read the *For Lubuntu 18.04*

Source:
<https://askubuntu.com/questions/81383/how-can-i-add-new-autostart-programs-in-lubuntu>
