Source:
<https://www.cyberciti.biz/faq/unix-linux-bsd-appleosx-bash-assign-variable-command-output/>\
**Important Note:** Don’t use any space before and after the equal sign when using the above commands.

 

