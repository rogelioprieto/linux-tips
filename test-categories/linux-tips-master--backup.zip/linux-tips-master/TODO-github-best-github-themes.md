# Interesting themes for your blog:

## - minimal mistakes

<https://github.com/mmistakes/minimal-mistakes/>\
<https://trevorstephens.com/categories/>

## - clean blog
https://github.com/blackrockdigital/startbootstrap-clean-blog-jekyll/


Sites to get free pictures for your blog:
https://unsplash.com/
