# Create a shortcut for URL?

1. Create a new file with ```.desktop``` extension.

2. Insert this content. You can chante Name and URL contents.

```
[Desktop Entry]
Encoding=UTF-8
Name=Link to Stack Overflow
Type=Link
URL=https://stackoverflow.com/
Icon=text-html
```

Source: <https://askubuntu.com/questions/359492/create-a-shortcut-for-url>
