Source:  
<https://apple.stackexchange.com/questions/134713/can-you-add-blank-space-to-a-photo-in-mac-preview/199108>
